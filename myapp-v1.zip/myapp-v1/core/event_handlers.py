from typing import Callable
from fastapi import FastAPI
import logging

from myapp.core.config import settings
from myapp.services.models import ZeroShotTextClassifier
from myapp.core.messages import MODEL_LOADING_SUCCESS, MODEL_LOADING_ERROR

logger = logging.getLogger(__name__)


def _startup_model(app: FastAPI) -> None:
    try:
        logger.info("Loading ZeroShotTextClassifier model.")
        model_instance = ZeroShotTextClassifier()
        app.state.model = model_instance
        logger.info(MODEL_LOADING_SUCCESS)
    except Exception as e:
        logger.error(f"{MODEL_LOADING_ERROR}: {e}")


def _shutdown_model(app: FastAPI) -> None:
    logger.info("Shutting down ZeroShotTextClassifier model.")
    app.state.model = None


def start_app_handler(app: FastAPI) -> Callable:
    def startup() -> None:
        logger.info("Running app start handler.")
        _startup_model(app)

    return startup


def stop_app_handler(app: FastAPI) -> Callable:
    def shutdown() -> None:
        logger.info("Running app shutdown handler.")
        _shutdown_model(app)

    return shutdown
