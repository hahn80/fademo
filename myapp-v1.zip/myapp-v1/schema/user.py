#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import annotations
from pydantic import BaseModel, EmailStr


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserCreate(BaseModel):
    email: EmailStr
    password: str


class UserResponse(BaseModel):
    email: EmailStr

    class Config:
        from_attributes = True
