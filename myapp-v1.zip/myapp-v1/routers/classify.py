from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from myapp.core.security import validate_token
from myapp.schema.classify import ZeroClassificationInput, ZeroClassificationOutput
from myapp.services.models import ZeroShotTextClassifier

router = APIRouter()
auth_scheme = HTTPBearer()


default_data = ZeroClassificationInput(
    text="I have a problem with my iPhone that needs to be resolved asap!",
    candidate_labels=["urgent", "not urgent", "phone", "tablet", "computer"],
).dict()


@router.post("/classify", response_model=ZeroClassificationOutput, name="classify")
def classify(
    data: ZeroClassificationInput = default_data.copy(),
    token: HTTPAuthorizationCredentials = Depends(auth_scheme),
) -> ZeroClassificationOutput:
    # Validate the Bearer token
    validate_token(token.credentials)

    # Perform classification using ZeroShotTextClassifier
    classifier = ZeroShotTextClassifier()
    prediction: ZeroClassificationOutput = classifier.predict(data)

    return prediction
